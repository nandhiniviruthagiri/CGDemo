import { TestBed } from '@angular/core/testing';

import { TransFetcherService } from './trans-fetcher.service';
 
describe('TransFetcherService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TransFetcherService = TestBed.get(TransFetcherService);
    expect(service).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-give-back',
  templateUrl: './give-back.page.html',
  styleUrls: ['./give-back.page.scss'],
})
export class GiveBackPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

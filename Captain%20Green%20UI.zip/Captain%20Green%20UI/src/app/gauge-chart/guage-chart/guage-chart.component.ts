import { CourseDialogComponent } from './../../course-dialog/course-dialog.component';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Component, OnInit, ViewChild, AfterViewInit, Input, OnChanges } from '@angular/core';
import * as Highcharts from 'highcharts';
import HighchartsMore from "highcharts/highcharts-more.src.js";
import solidGauge from "highcharts/modules/solid-gauge.js";

HighchartsMore(Highcharts);

solidGauge(Highcharts);
@Component({
  selector: 'app-guage-chart',
  templateUrl: './guage-chart.component.html',
  styleUrls: ['./guage-chart.component.scss'],
})
export class GuageChartComponent implements OnInit, OnChanges {
  @Input() aggregatedCarbon;
  @Input() maxGoal;
  // @ViewChild('chart',{static: false}) chart;
  Highcharts: typeof Highcharts = Highcharts;
  public updateFlag = false;
  public chartValue = this.aggregatedCarbon;
  private gaugeUpdateInterval;


  public options = {
    chart: {
      type: "solidgauge"
    },

    title: null,
    pane: {
      center: ["50%", "85%"],
      size: "140%",
      startAngle: -90,
      endAngle: 90,
      background: {
        backgroundColor:
          Highcharts.defaultOptions.legend.backgroundColor || '#EEE',
        innerRadius: "60%",
        outerRadius: "100%",
        shape: "arc"
      }
    },
    exporting: {
      enabled: false
    },

    tooltip: {
      enabled: false
    },

    // yAxis: {
    //   stops: [[0.1, "#DF5353"], [0.5, "#DDDF0D"], [0.9, "#55BF3B"]],
    //   min: 0,
    //   max: 100,
    //   lineWidth: 0,
    //   tickAmount: 2,
    //    title: {
    //         y: -70
    //     },
    //   labels: {
    //     y: 16
    //   }
    // },


    plotOptions: {
      solidgauge: {
        dataLabels: {
          y: 5,
          borderWidth: 0,
          useHTML: true
        }
      }
    },
    yAxis: {
      // stops: [[0.1, "#55BF3B"], [0.5, "#DDDF0D"], [0.9, "#DF5353"]],
      stops: [
        [0.5, {
          linearGradient: {
            x1: 0,
            x2: 0,
            y1: 0,
            y2: 1
          },
          stops: [
            [0, '#55BF3B'],
            [1, '#DDDF0D']
          ]
        }],
        [0.9, {
          linearGradient: {
            x1: 0,
            x2: 1,
            y1: 0,
            y2: 0
          },
          stops: [
            [0, '#55BF3B'],
            [0.5, '#DDDF0D'],
            [1, '#DF5353']
          ]
        }]
      ],
      min: 0,
      max: 1000,
      lineWidth: 0,
      tickAmount: 1,
      tickWidth: 0,
      tickPositioner: function () {
        return [this.min, this.max];
      },
      endOnTick: false,
      minorTickInterval: null,
      labels: {
        y: 16
      },
      title: {
        y: -70,
        text: ''
      }
    },
    credits: {
      enabled: false
    },
    series: [
      {
        name: "Carbon Footprint",
        data: [this.chartValue],
        dataLabels: {
          format:
            '<div style="text-align:center">' +
            '<span style="font-size:20px">{y}</span><br/>' +
            '<span style="font-size:12px;opacity:0.4">KgCO<sub>2</sub></span>' +
            '</div>'
        },
        tooltip: {
          valueSuffix: 'KgCO2'
        }
      }
    ]
  };

  constructor(private dialog: MatDialog) {
    Highcharts.charts.forEach(function (chart) {
      chart.reflow();
    });
  }
  ngOnInit() {
    console.log("0"+this.aggregatedCarbon);
    if (this.aggregatedCarbon && this.maxGoal) {
      this.updateChart(this.aggregatedCarbon);
      Highcharts.charts.forEach(function (chart) {
        chart.reflow();
      });
    }

    Highcharts.charts.forEach(function (chart) {
      console.log(chart);
      chart.reflow();
    });



  }

  cb = function (chart) {
    setTimeout(function () {
      chart.reflow();
    }, 0);
  };

  private updateChart(value) {
    this.chartValue = value;
    console.log(this.maxGoal)
    // first try - working without transition
    this.options.series[0].data[0] = value;
    this.options.yAxis.max = this.maxGoal;
    this.updateFlag = true;

   /* Highcharts.charts.forEach(function (chart) {
      console.log(chart);
      chart.reflow();
    });*/
  }

  ngOnChanges() {
    console.log("onchange");
    if (this.aggregatedCarbon && this.maxGoal) {
      this.updateChart(this.aggregatedCarbon);
    }
  }



  openDialog() {

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;

    const dialogRef = this.dialog.open(CourseDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.updateChart(this.aggregatedCarbon);
    });
  }



}

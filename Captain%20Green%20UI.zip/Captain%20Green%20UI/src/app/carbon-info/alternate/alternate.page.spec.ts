import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AlternatePage } from './alternate.page';

describe('AlternatePage', () => {
  let component: AlternatePage;
  let fixture: ComponentFixture<AlternatePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlternatePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AlternatePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { CarbonTrendsPageModule } from './../carbon-trends/carbon-trends.module';
import { CarbonCalcPageModule } from './../carbon-calc/carbon-calc.module';
import { CarbonInfoPageModule } from './../carbon-info/carbon-info.module';
import {GiveBackPageModule} from './../carbon-info/give-back/give-back.module';
//import {PageTestPageModule} from './../carbon-info/page-test/page-test.module';
import {AlternatePageModule} from './../carbon-info/alternate/alternate.module'
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';
console.log("gg");
const routes: Routes = [
  {
    path: '',
    component: TabsPage,
    children: [
      {
        path: 'tab1',
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../tab1/tab1.module').then(m => m.Tab1PageModule)
          }
        ]
      },
      {
        path: 'carbon-trends',
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../carbon-trends/carbon-trends.module').then(m => m.CarbonTrendsPageModule)
          }
        ]
      },
      {
        path: 'carbon-calc',
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../carbon-calc/carbon-calc.module').then(m => m.CarbonCalcPageModule)
          }
        ]
      },
      {
        path: 'carbon-info',
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../carbon-info/carbon-info.module').then(m => m.CarbonInfoPageModule)
          },
          {
            path:'give-back',
            loadChildren: () =>
            import('../carbon-info/give-back/give-back.module').then(m => m.GiveBackPageModule)
            
           },
           {
            path:'alternate',
            loadChildren: () => import('../carbon-info/alternate/alternate.module').then( m => m.AlternatePageModule)        
           },
        ]
      },
      // {
      //   path: 'carbon-info/give-back', 
      //   children:[
      //     {
      //      path:'',
      //      loadChildren: () =>
      //      import('../carbon-info/give-back/give-back.module').then(m => m.GiveBackModule)
           
      //     }
      //   ]
      // },
      {
        path: '',
        redirectTo: '/tabs/tab1',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/tabs/tab1',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TabsPageRoutingModule {}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { CarbonTrendsPage } from './carbon-trends.page';

describe('CarbonTrendsPage', () => {
  let component: CarbonTrendsPage;
  let fixture: ComponentFixture<CarbonTrendsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarbonTrendsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(CarbonTrendsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { TransFetcherService } from './../trans-fetcher.service';
import { SharedDataServiceService } from './../shared-services/shared-data-service.service';
import { Component, OnInit, Inject } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material";

@Component({
  selector: 'app-course-dialog',
  templateUrl: './course-dialog.component.html',
  styleUrls: ['./course-dialog.component.scss'],
})
export class CourseDialogComponent implements OnInit {
  aggregatedSum;
  value = 8500;

  constructor(private dialogRef: MatDialogRef<CourseDialogComponent>, private sharedDataServiceService:  SharedDataServiceService, private transFetcherService: TransFetcherService,
    @Inject(MAT_DIALOG_DATA) data) { }

 
//   public onLoginClick(){
//     console.log('navigating');
//     console.log(this.value);
//     this.sharedDataServiceService.setGoal = this.value;
//     this.router.navigate(['./tabs']);
// }


formatLabel(value: number) {
  if (value >= 1000) {
    return Math.round(value / 1000) + 'k';
  }

  return value;
}

  ngOnInit() {
    this.transFetcherService.getTransactions().subscribe((data) => {
      this.aggregatedSum = Number(data.Totals.aggregatedCarbon);
    });
  }

  changeValue(changedValue) {
    console.log(changedValue.value);
    console.log(this.value);
    this.sharedDataServiceService.setGoal = this.value;
  }
  save() {
    this.sharedDataServiceService.setGoal = this.value;

    this.dialogRef.close(this.value);
}

close() {
    this.dialogRef.close();
}

}

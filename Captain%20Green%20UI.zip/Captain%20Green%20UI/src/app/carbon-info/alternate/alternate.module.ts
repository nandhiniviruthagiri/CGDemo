import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AlternatePageRoutingModule } from './alternate-routing.module';

import { AlternatePage } from './alternate.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AlternatePageRoutingModule
  ],
  declarations: [AlternatePage]
})
export class AlternatePageModule {}

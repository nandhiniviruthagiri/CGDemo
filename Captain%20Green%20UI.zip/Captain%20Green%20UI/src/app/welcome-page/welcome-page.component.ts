import { SharedDataServiceService } from './../shared-services/shared-data-service.service';
import { TransFetcherService } from './../trans-fetcher.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-welcome-page',
  templateUrl: './welcome-page.component.html',
  styleUrls: ['./welcome-page.component.scss'],
})
export class WelcomePageComponent implements OnInit {
  aggregatedSum;
  value = 8500;
 
  constructor(private transFetcherService: TransFetcherService, private router: Router, 
    private sharedDataServiceService: SharedDataServiceService) { }

  public onLoginClick(){
    console.log('navigating');
    console.log(this.value);
    this.sharedDataServiceService.setGoal = this.value;
    this.aggregatedSum = this.value;
    //this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
    this.router.navigate(['./tabs']);
    
}


formatLabel(value: number) {
  if (value >= 1000) {
    return Math.round(value / 1000) + 'k';
  }

  return value;
}

  ngOnInit() {
    this.transFetcherService.getTransactions().subscribe((data) => {
      this.aggregatedSum = Number(data.Totals.aggregatedCarbon);
    });
  }

  changeValue(changedValue) {
    console.log("changed"+changedValue.value);
    console.log("val"+this.value);
    this.sharedDataServiceService.setGoal = this.value;
  }
}

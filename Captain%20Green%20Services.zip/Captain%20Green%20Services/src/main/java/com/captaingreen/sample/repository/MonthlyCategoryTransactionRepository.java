package com.captaingreen.sample.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.captaingreen.sample.entity.SampleEntity;
import com.captaingreen.sample.entity.DailyCategoryTransactionEntity;
import com.captaingreen.sample.entity.DailyTransactionEntity;
import com.captaingreen.sample.entity.MonthlyCategoryTransactionEntity;
 
@Repository
public interface MonthlyCategoryTransactionRepository extends CrudRepository<MonthlyCategoryTransactionEntity, Long> {
 
	@Query(
			  value = "SELECT * FROM [dbo].[TransactionData]\r\n" + 
			  		"INNER JOIN (SELECT MAX(TransactionDate) CurrentDate FROM [dbo].[TransactionData])CurrentTransaction  \r\n" + 
			  		"ON MONTH(CurrentTransaction.CurrentDate) = MONTH(TransactionDate)",
			  nativeQuery = true)
    public List<MonthlyCategoryTransactionEntity> getAll();
	
}
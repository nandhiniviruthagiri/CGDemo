import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { TransFetcherService } from './../trans-fetcher.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-carbon-calc',
  templateUrl: './carbon-calc.page.html',
  styleUrls: ['./carbon-calc.page.scss'],
})
export class CarbonCalcPage implements OnInit {


  selectedDate = new Date();
  startAt = new Date('2020/01/01');
  minDate = new Date('2019/09/14');
  maxDate = new Date(new Date().setMonth(new Date().getMonth() + 1));
  year: any;
  DayAndDate: string;
  calendarTrans: any;
  imageSrc = "./../../assets/Jan.PNG";
  imageSrc1 = "./../../assets/Feb2.PNG";
  constructor(private datePipe: DatePipe, private transFetcherService: TransFetcherService) {
  }
  toJan(){    
    console.log("Jan is clicked!");  
    document.getElementById('jan').style.cssText = 'display:block';  
    document.getElementById('feb').style.cssText = 'display:none'; 
    document.getElementById('calImg').style.cssText = 'display:block';  
    document.getElementById('calImg1').style.cssText = 'display:none';  
  }  
  toFeb(){    
    console.log("Feb is clicked!");   
    document.getElementById('jan').style.cssText = 'display:none';  
    document.getElementById('feb').style.cssText = 'display:block'; 
    document.getElementById('calImg').style.cssText = 'display:none';  
    document.getElementById('calImg1').style.cssText = 'display:block';  
  }   
  ngOnInit() {
    this.onSelect(this.selectedDate);
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    console.log(currentMonth);
    // make http call to color the grid,


    this.transFetcherService.getCalendarTransactions(12, 2019).subscribe((data) => {

      // this.transFetcherService.getCalendarTransactions(currentMonth + 1, currentYear).subscribe((data) => {
      console.log(data);
      this.calendarTrans = data;
      console.log(data);
    });

  }

  onSelect(event) {
    console.log(event);
    this.selectedDate = event;
    const dateString = event.toDateString();
    const dateValue = dateString.split(' ');
    this.year = dateValue[3];
    this.DayAndDate = dateValue[0] + ',' + ' ' + dateValue[1] + ' ' + dateValue[2];
  }

  // myDateFilter = (d: Date): boolean => {
  //   const day = d.getDay();
  //   // Prevent Saturday and Sunday from being selected.
  //   return day !== 0 && day !== 6 ;
  // }


  dateClass = (d: Date) => {
    console.log(d);
    const date = d.getDate();
    console.log(date);
    // Highlight the 1st and 20th day of each month.

    const formattedDate = this.TransformDate(d);
    console.log(formattedDate);

    let dateObj;

    if (this.calendarTrans) {
      dateObj = this.calendarTrans.find((trans) => {
        return trans && trans.transactionDate === formattedDate;
      });
      console.log(dateObj);
    }


    if ((dateObj  && Number(dateObj.carbonEmmitted)) <= 200 && (dateObj  && Number(dateObj.carbnEmmitted))) {
      return 'custom-date-class-green';
    }

    if ( (dateObj  && Number(dateObj.carbnEmmitted)) > 200 && (dateObj  && Number(dateObj.carbnEmmitted)) <= 700 ) {
      return 'custom-date-class-yellow';
    }

    if ((dateObj  && Number(dateObj.carbnEmmitted)) > 700) {
      return 'custom-date-class-red';
    } else {
      return 'custom-date-class-red';
    }
  }

  TransformDate(currentDate) {
    return this.datePipe.transform(currentDate, 'yyyy-MM-dd');
  }

}

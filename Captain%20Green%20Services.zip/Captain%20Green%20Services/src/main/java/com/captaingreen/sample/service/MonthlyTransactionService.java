package com.captaingreen.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.captaingreen.sample.entity.SampleEntity;
import com.captaingreen.sample.entity.DailyTransactionEntity;
import com.captaingreen.sample.entity.MonthlyTransactionEntity;
import com.captaingreen.sample.entity.MonthlyTransactionEntity;
import com.captaingreen.sample.repository.SampleRepository;
import com.captaingreen.sample.repository.DailyTransactionRepository;
import com.captaingreen.sample.repository.MonthlyTransactionRepository;
 
@Service
public class MonthlyTransactionService {
 
    @Autowired
    MonthlyTransactionRepository monthlytransactionRepo;
 
       /* public List<MonthlyTransactionEntity> getAll() {
            return monthlytransactionRepo.getAll();
        }*/

		public List<MonthlyTransactionEntity> getResponse(int month, int year) {
			return monthlytransactionRepo.getResponse(month,year);
		}
}
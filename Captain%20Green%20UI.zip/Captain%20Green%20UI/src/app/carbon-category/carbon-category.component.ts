import { TransFetcherService } from './../trans-fetcher.service';
import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import HighchartsMore from 'highcharts/highcharts-more.src.js';
import solidGauge from 'highcharts/modules/solid-gauge.js';
import { Food } from './carbon-category/selectoptions';

HighchartsMore(Highcharts);

solidGauge(Highcharts);

@Component({
    selector: 'app-carbon-category',
    templateUrl: './carbon-category.component.html',
    styleUrls: ['./carbon-category.component.scss'],
})
export class CarbonCategoryComponent implements OnInit {

    updateFlag = false;
    sampleData2 = { 'Transactions': [] };

    highChartColors;
    iconMapperWithColor;

    iconsMapper = {
        'Travel': 'flight',
        "Food and Drinks": 'emoji_food_beverage',
        'Shopping': 'shopping_basket',
        'Gift': 'card_giftcard',
        'Misc': 'dashboard',
        'Home': 'home'
    };

    constructor(private transFetcherService: TransFetcherService) { }

    Highcharts: typeof Highcharts = Highcharts;

    chartOptions2 = {
        chart: {
            type: 'pie'
        },

        plotOptions: {
            pie: {
                innerSize: '70%',
                dataLabels: {
                    enabled: false
                }, colors: ['#005AA4', '#00A1E2', '#6769B5', '#3BC3A3', '#002B51' , '#D0B86A', '#6FC8CB', '#93959B']
            }
        },

        title: {
            verticalAlign: 'middle',
            text: '23,123<br>KgCO2'
        },

        series: [{
            data: [["Food and Drinks", 2871.218],
            ["Gifts", 163.79999],
            ["Shopping", 61.783302],
            ["Travel", 1161.8098]],
            name: 'KgCO2'
        }]
    };

    ngOnInit() {
        this.transFetcherService.getMonthlyTransactions().subscribe((data) => {
            this.updateChartOption(data);
            // this.highChartColors = Highcharts.getOptions().colors;
            // console.log(this.highChartColors);
            // this.iconMapperWithColor = this.createIconMapperColors(this.highChartColors, arrayOfCategorories);
            console.log(this.iconMapperWithColor);

            Highcharts.charts.forEach(function (chart) {
                chart.reflow();
            });
        });





    }

    updateChartOption(data) {
        this.sampleData2 = data;

        const updatedData = Object.assign(data);
        // let newArray;
        // if (updatedData.Transactions) {
        const [newArray, arrayOfCategorories] = updatedData.Transactions.reduce(([acc, acc2], trans) => {
            const transData = [trans.categoryName, Number(trans.carbonEmission)];
            const modifiedTransArray = [...acc, transData];
            const modifiedCategoryArray = [...acc2, trans.categoryName]
            return [modifiedTransArray, modifiedCategoryArray];
        }, [[], []]);
        // }

        console.log(newArray);
        console.log(arrayOfCategorories);
        console.log(data);


        this.updateChart(newArray, updatedData.Totals);
        this.highChartColors = this.chartOptions2.plotOptions.pie.colors;
        console.log(this.highChartColors);
        this.iconMapperWithColor = this.createIconMapperColors(this.highChartColors, arrayOfCategorories);
        console.log(this.iconMapperWithColor)


    }

    showDailyTransactions() {

        this.transFetcherService.getDailyTransactions().subscribe(
            data => {
                this.sampleData2 = data;
                console.log("daily category transactions", this.sampleData2);
                this.updateChartOption(data);
            }
        );
    }
    showMonthlyTransactions() {

        this.transFetcherService.getMonthlyTransactions().subscribe(
            data => {
                this.sampleData2 = data;
                console.log("monthly category transactions", this.sampleData2);
                this.updateChartOption(data);
            }

        );
    }


    showWeeklyTransactions() {

        this.transFetcherService.getWeeklyTransactions().subscribe(
            data => {
                this.sampleData2 = data;
                //console.log("weekly category transactions",this.sampleData4);
                this.updateChartOption(data);

            }

        )
    }
    createIconMapperColors(colors, currentCategory) {
        const newMappedArray = currentCategory.reduce((acc, currentCategoryObj) => {
            const newObj = {
                ...acc, [currentCategoryObj]: {
                    icon: this.iconsMapper[currentCategoryObj],
                    color: colors[currentCategory.indexOf(currentCategoryObj)]
                }
            }
            return newObj;
        }, this.iconsMapper);
        return newMappedArray;
    }

    cb = function (chart) {
        setTimeout(function () {
            chart.reflow();
        }, 0);
    };


    updateChart(newArrayData, totals) {
        this.chartOptions2.series[0].data = newArrayData;
        this.chartOptions2.title.text = Number.parseFloat(totals.aggregatedCarbon).toFixed(2) + '<br>KgCO2';
        this.updateFlag = true;
    }
}

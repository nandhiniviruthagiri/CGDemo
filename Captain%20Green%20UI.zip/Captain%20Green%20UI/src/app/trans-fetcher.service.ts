import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class TransFetcherService {
  private transUrl = 'https://captaingreen-services.azurewebsites.net/dailytransactiondataformatted';
  constructor(private http: HttpClient) { }

  getTransactions(): Observable<any> {
    return this.http.get(this.transUrl).pipe(
      catchError(this.handleError('getTransactions'))
    )
  }

  private dailyTransUrl = 'https://captaingreen-services.azurewebsites.net/dailycategorytransactiondata';
  getDailyTransactions(): Observable<any> {
    return this.http.get(this.dailyTransUrl).pipe(
      catchError(this.handleError('getTransactions'))
    );
  }

  private dailyCalendarUrl = 'https://captaingreen-services.azurewebsites.net/monthlytransactiondata/';
    getCalendarTransactions(month, year): Observable<any> {
      const updatedURL = this.dailyCalendarUrl + month + '/' + year;
      return this.http.get(updatedURL).pipe(
        catchError(this.handleError('getTransactions'))
      );
    }

    private monthlyTransUrl = 'https://captaingreen-services.azurewebsites.net/monthlycategorytransactiondata ';
    getMonthlyTransactions(): Observable<any> {
      const updatedURL = this.monthlyTransUrl;
      return this.http.get(updatedURL).pipe(
        catchError(this.handleError('getTransactions'))
      );
    }

    private weeklyTransUrl = 'https://captaingreen-services.azurewebsites.net/weeklycategorytransactiondata ';
    getWeeklyTransactions(): Observable<any> {
      const updatedURL = this.weeklyTransUrl;
      return this.http.get(updatedURL).pipe(
        catchError(this.handleError('getTransactions'))
      );
    }


  private handleError<T>(result ?: T) {
  return (error: any): Observable<T> => {

    // TODO: send the error to remote logging infrastructure
    console.error(error); // log to console instea
    // Let the app keep running by returning an empty result.
    return of(result as T);
  };
}
}

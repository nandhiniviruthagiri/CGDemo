import { FormsModule } from '@angular/forms';
import { MaterialModule } from './../../material.module';
import { IonicModule } from '@ionic/angular';
import { WelcomePageComponent } from './../welcome-page.component';
import { WelcomePageRoutingModule } from './welcome-page-routing.module';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [WelcomePageComponent],
  imports: [
    CommonModule,
    IonicModule,
    MaterialModule,
    FormsModule,
    WelcomePageRoutingModule
  ]
})
export class WelcomePageModule { }

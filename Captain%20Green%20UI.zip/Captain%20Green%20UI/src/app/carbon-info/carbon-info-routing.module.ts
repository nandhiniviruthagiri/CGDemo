import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import {GiveBackComponent} from './carbon-info/give-back/GiveBackComponent/';

import { CarbonInfoPage } from './carbon-info.page';
import { GiveBackPageModule } from './give-back/give-back.module';

const routes: Routes = [
  {
    path: '',
    component: CarbonInfoPage,
    // children: [                          //<---- child components declared here
    //   {
    //       //path:'give-back',
    //       //loadChildren: () =>
    //         //import('../carbon-info/give-back/give-back.module').then(m => m.GiveBackPageModule)
    //   }
    // ]
  },
  {
    path: 'alternate',
    loadChildren: () => import('./alternate/alternate.module').then( m => m.AlternatePageModule)
  },
  {
    path: 'give-back',
    loadChildren: () => import('./give-back/give-back.module').then( m => m.GiveBackPageModule)
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CarbonInfoPageRoutingModule {}

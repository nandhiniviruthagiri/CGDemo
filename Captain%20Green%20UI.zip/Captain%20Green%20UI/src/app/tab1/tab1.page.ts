import { CourseDialogComponent } from './../course-dialog/course-dialog.component';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { SharedDataServiceService } from './../shared-services/shared-data-service.service';
import { TransFetcherService } from './../trans-fetcher.service';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit {
  transData$: Observable<any>;
  aggregatedSum; 
  goalSet; 
  iconsMapper = {
    'Travel': 'flight',
    "Food and Drinks": 'emoji_food_beverage',
    'Shopping': 'shopping_basket',
    'Gift': 'card_giftcard',
    'Misc': 'dashboard',
    'Home': 'home'
  };



  sampleData2 = {
    Totals: {},
    Transactions: []
  };



  constructor(private dialog: MatDialog, private transFetcherService: TransFetcherService, private sharedDataServiceService: SharedDataServiceService,private router: Router) { }

  ngOnInit() {
    console.log("tt");
    this.transFetcherService.getTransactions().subscribe((data) => {
      this.sampleData2 = data;
      this.aggregatedSum = Number(data.Totals.aggregatedCarbon);
    });
console.log("tt");
    this.goalSet = this.sharedDataServiceService.setGoal ? this.sharedDataServiceService.setGoal : 10000;
    // this.openDialog();
  }

  public setGoal(){
    console.log('navigating');
    this.router.navigate(['./welcome-page']);
}


  getIconColor() {
    return {
   'background-color': '#F6F4F3',
    'border-radius': '24%'
  };
 }

 openDialog() {

  const dialogConfig = new MatDialogConfig();

  dialogConfig.disableClose = true;
  dialogConfig.autoFocus = true;

  const dialogRef = this.dialog.open(CourseDialogComponent, dialogConfig);
  dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');
    this.goalSet = result;
  });
}


}

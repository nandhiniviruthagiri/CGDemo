import { MaterialModule } from './../material.module';
import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CarbonCalcPageRoutingModule } from './carbon-calc-routing.module';

import { CarbonCalcPage } from './carbon-calc.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    IonicModule,
    CarbonCalcPageRoutingModule
  ],
  declarations: [CarbonCalcPage],
  providers: [DatePipe]
 
})
export class CarbonCalcPageModule {}

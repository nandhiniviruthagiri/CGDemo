package com.captaingreen.sample.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.captaingreen.sample.entity.DailyCategoryTransactionEntity;
import com.captaingreen.sample.entity.DailyTransactionEntity;
import com.captaingreen.sample.entity.MonthlyCategoryTransactionEntity;
import com.captaingreen.sample.entity.MonthlyTransactionEntity;
import com.captaingreen.sample.entity.MonthlyTransactionEntity;
import com.captaingreen.sample.entity.SampleEntity;
import com.captaingreen.sample.entity.WeeklyCategoryTransactionEntity;
import com.captaingreen.sample.service.CategoryServices;
import com.captaingreen.sample.service.DailyCategoryTransactionService;
import com.captaingreen.sample.service.DailyTransactionService;
import com.captaingreen.sample.service.MonthlyCategoryTransactionService;
import com.captaingreen.sample.service.MonthlyTransactionService;
import com.captaingreen.sample.service.SampleService;
import com.captaingreen.sample.service.WeeklyCategoryTransactionService;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
 
import com.microsoft.applicationinsights.TelemetryClient;

@RestController
public class SampleController {
 
    @Autowired
    SampleService sampleService;
    
    @Autowired
    DailyTransactionService dailytransactionService;
    
    @Autowired
    DailyCategoryTransactionService dailycategorytransactionService;
    
    @Autowired
    WeeklyCategoryTransactionService weeklycategorytransactionService;
    
    @Autowired
    MonthlyCategoryTransactionService monthlycategorytransactionService;
    
    @Autowired
    MonthlyTransactionService monthlytransactionService;
    
    @Autowired
    TelemetryClient telemetryClient;
    
    @CrossOrigin
    @RequestMapping(value = "/hello")
    public String test() {
    	//track a custom event  
        telemetryClient.trackEvent("Sending a custom event...");
    	return "hi!";
    }
    
    @CrossOrigin
    @RequestMapping(value = "/sample")
    public List<SampleEntity> sample() {
        return sampleService.getAll();
    }
    
    @CrossOrigin
    @RequestMapping(value = "/dailytransactiondata")
    public List<DailyTransactionEntity> dailytransaction() {
    return dailytransactionService.getAll();
    }
    
    @CrossOrigin
    @RequestMapping(value = "/dailytransactiondataformatted")
    public JSONObject dailytransactionformatted() {
    	List<DailyTransactionEntity> allTransactions = dailytransactionService.getAll();
    	String month = allTransactions.get(0).getTransactiondate().toString().split("-")[1];
    	Map<String,JSONArray> dayWiseTransactions = new LinkedHashMap<>();
    	ListIterator<DailyTransactionEntity> dailytransactionIterator = allTransactions.listIterator();
    	JSONObject carbonInfo = null;
    	JSONArray perDayTransactions = new JSONArray();
    	long totalCarbonEmission = 0L;
    	long totalTransactionAmount = 0L;
    	while(dailytransactionIterator.hasNext()) {
    		DailyTransactionEntity transaction = dailytransactionIterator.next();
    		String date = transaction.getTransactiondate().toString();
    		if(date.split("-")[1].equalsIgnoreCase(month)) {
    			carbonInfo = new JSONObject();
				carbonInfo.put("merchantName", transaction.getMerchantname());
				carbonInfo.put("subheader", transaction.getMerchantname());
				
				//Calculating aggregated values
				totalTransactionAmount += transaction.getTransactionAmount();
				totalCarbonEmission += transaction.getTotalcarbonindex();
				
				carbonInfo.put("trans_amt", String.valueOf(transaction.getTransactionAmount()));
				carbonInfo.put("carbonEmission", String.valueOf(transaction.getTotalcarbonindex()));
				carbonInfo.put("categoryName", transaction.getTransactioncategory());
				carbonInfo.put("category_d", transaction.getTransactioncategory());
    			if(dayWiseTransactions.containsKey(date)) {
    				perDayTransactions = dayWiseTransactions.get(date);
    				perDayTransactions.add(carbonInfo);
    				dayWiseTransactions.put(date,perDayTransactions);
    			}else {
    				perDayTransactions = new JSONArray();
    				perDayTransactions.add(carbonInfo);
    				dayWiseTransactions.put(date,perDayTransactions);
    			}
    		}
    	}
    	JSONArray transactions = new JSONArray();
    	for(Map.Entry<String,JSONArray> transactionEntry : dayWiseTransactions.entrySet()) {
    		JSONObject transactionInfo = new JSONObject();
    		transactionInfo.put("transactionDate", transactionEntry.getKey());
    		transactionInfo.put("purchases", transactionEntry.getValue());
    		transactions.add(transactionInfo);
    	}
    	JSONObject totals = new JSONObject();
    	totals.put("aggregatedSum", String.valueOf(totalTransactionAmount));
    	totals.put("aggregatedCarbon", String.valueOf(totalCarbonEmission));
    	
    	JSONObject dailyTransactionResponse = new JSONObject();
    	dailyTransactionResponse.put("Totals", totals);
    	dailyTransactionResponse.put("Transactions", transactions);
    	return dailyTransactionResponse;
    }
    
    @CrossOrigin
    @RequestMapping(value = "/dailycategorytransactiondataTest")
    public List<DailyCategoryTransactionEntity> dailycategorytransactionTest() {
    	List<DailyCategoryTransactionEntity> dailycategoryTransactionList=dailycategorytransactionService.getAll();
    	return dailycategoryTransactionList;   	
    }
    
    @CrossOrigin
    @RequestMapping(value = "/categories")
    public JSONArray categories() {
    	CategoryServices categoryservices=new CategoryServices();
		ArrayList<String> categoryArray = null;
		categoryArray=categoryservices.getCategories();
		JSONArray response = new JSONArray();
		for(String cat : categoryArray) {
			response.add(cat);
		}
    	return response;   	
    }
    
    @CrossOrigin
    @RequestMapping(value = "/dailycategorytransactiondata")
    public JSONObject dailycategorytransaction() {
    	CategoryServices categoryservices=new CategoryServices();
		ArrayList<String> categoryArray = null;
		JSONObject categoryObject = null;
    	List<DailyCategoryTransactionEntity> dailycategoryTransactionList=dailycategorytransactionService.getAll();
    	ListIterator<DailyCategoryTransactionEntity> dailycategorytransactionIterator = dailycategoryTransactionList.listIterator();
    	 
    	categoryArray=categoryservices.getCategories();
    	float aggregatedSum = 0.0f;
    	float aggregatedCarbon = 0.0f;
    	System.out.println("Catgeories " + categoryArray.size() + " "+ categoryArray.get(0) + " " + categoryArray.get(1));
    	ListIterator<String> iterator = categoryArray.listIterator();
    	JSONArray transactionsArray = new JSONArray();
		while(iterator.hasNext()) {
		String category=iterator.next();
		System.out.println("Calculating for category: "+category);
		float transactionAmountCat = 0.0f;
		float carbonEmissionCat = 0.0f;
		int transactionCnt = 0;
		dailycategorytransactionIterator = dailycategoryTransactionList.listIterator();
		while(dailycategorytransactionIterator.hasNext()) {
			DailyCategoryTransactionEntity e = dailycategorytransactionIterator.next();
			System.out.println("transaction category : "+e.getTransactioncategory());
			if(category.equalsIgnoreCase(e.getTransactioncategory())) {
				System.out.println("matched category: "+category);
				transactionAmountCat += e.getTransactionAmount();
				carbonEmissionCat += e.getTotalcarbonindex();
				transactionCnt++;
			}
		} 
		categoryObject = new JSONObject();
		categoryObject.put("carbonEmission", String.valueOf(carbonEmissionCat));
		categoryObject.put("trans_amt", String.valueOf(transactionAmountCat));
		categoryObject.put("categoryName", category);
		categoryObject.put("category_d", category);
		categoryObject.put("subheader", String.valueOf(transactionCnt)+" transactions");
		System.out.println("Adding category : "+category + " carbon emission: " + String.valueOf(carbonEmissionCat));
		aggregatedSum += transactionAmountCat;
		aggregatedCarbon += carbonEmissionCat;
		transactionsArray.add(categoryObject);
		}
		
		JSONObject totals = new JSONObject();
		totals.put("aggregatedSum", String.valueOf(aggregatedSum));
		totals.put("aggregatedCarbon", String.valueOf(aggregatedCarbon));
		
		JSONObject dailyCategoryTransaction = new JSONObject();
		dailyCategoryTransaction.put("Totals", totals);
		dailyCategoryTransaction.put("Transactions", transactionsArray);
		return dailyCategoryTransaction;
   
    }
    
    @CrossOrigin
    @RequestMapping(value = "/weeklycategorytransactiondata")
    public JSONObject weeklycategorytransaction() {
    	CategoryServices categoryservices=new CategoryServices();
		ArrayList<String> categoryArray = null;
    	List<WeeklyCategoryTransactionEntity> weeklycategoryTransactionList=weeklycategorytransactionService.getAll();
    	ListIterator<WeeklyCategoryTransactionEntity> weeklycategorytransactionIterator = weeklycategoryTransactionList.listIterator();
    	JSONObject categoryObject = null;
    	categoryArray=categoryservices.getCategories();
    	float aggregatedSum = 0.0f;
    	float aggregatedCarbon = 0.0f;
    	System.out.println("Catgeories " + categoryArray.size() + " "+ categoryArray.get(0) + " " + categoryArray.get(1));
    	ListIterator<String> iterator = categoryArray.listIterator();
    	JSONArray transactionsArray = new JSONArray();
		while(iterator.hasNext()) {
		String category=iterator.next();
		System.out.println("Calculating for category: "+category);
		float transactionAmountCat = 0.0f;
		float carbonEmissionCat = 0.0f;
		int transactionCnt = 0;
		weeklycategorytransactionIterator = weeklycategoryTransactionList.listIterator();
		while(weeklycategorytransactionIterator.hasNext()) {
			WeeklyCategoryTransactionEntity e = weeklycategorytransactionIterator.next();
			System.out.println("transaction category : "+e.getTransactioncategory());
			if(category.equalsIgnoreCase(e.getTransactioncategory())) {
				System.out.println("matched category: "+category);
				transactionAmountCat += e.getTransactionAmount();
				carbonEmissionCat += e.getTotalcarbonindex();
				transactionCnt++;
			}
		} 
		categoryObject = new JSONObject();
		categoryObject.put("carbonEmission", String.valueOf(carbonEmissionCat));
		categoryObject.put("trans_amt", String.valueOf(transactionAmountCat));
		categoryObject.put("categoryName", category);
		categoryObject.put("category_d", category);
		categoryObject.put("subheader", String.valueOf(transactionCnt)+" transactions");
		System.out.println("Transaction array size : "+ transactionsArray.size());
		System.out.println("Adding category : "+category + " carbon emission: " + String.valueOf(carbonEmissionCat));
		aggregatedSum += transactionAmountCat;
		aggregatedCarbon += carbonEmissionCat;
		transactionsArray.add(categoryObject);
		}
		
		JSONObject totals = new JSONObject();
		totals.put("aggregatedSum", String.valueOf(aggregatedSum));
		totals.put("aggregatedCarbon", String.valueOf(aggregatedCarbon));
		
		JSONObject dailyCategoryTransaction = new JSONObject();
		dailyCategoryTransaction.put("Totals", totals);
		dailyCategoryTransaction.put("Transactions", transactionsArray);
		return dailyCategoryTransaction;
   
    }
    
    @CrossOrigin
    @RequestMapping(value = "/monthlycategorytransactiondata")
    public JSONObject monthlycategorytransaction() {
    	CategoryServices categoryservices=new CategoryServices();
		ArrayList<String> categoryArray = null;
    	List<MonthlyCategoryTransactionEntity> monthlycategoryTransactionList=monthlycategorytransactionService.getAll();
    	ListIterator<MonthlyCategoryTransactionEntity> monthlycategorytransactionIterator = monthlycategoryTransactionList.listIterator();
    	JSONObject categoryObject = null;
    	categoryArray=categoryservices.getCategories();
    	float aggregatedSum = 0.0f;
    	float aggregatedCarbon = 0.0f;
    	System.out.println("Catgeories " + categoryArray.size() + " "+ categoryArray.get(0) + " " + categoryArray.get(1));
    	ListIterator<String> iterator = categoryArray.listIterator();
    	JSONArray transactionsArray = new JSONArray();
		while(iterator.hasNext()) {
		String category=iterator.next();
		System.out.println("Calculating for category: "+category);
		float transactionAmountCat = 0.0f;
		float carbonEmissionCat = 0.0f;
		int transactionCnt = 0;
		monthlycategorytransactionIterator = monthlycategoryTransactionList.listIterator();
		while(monthlycategorytransactionIterator.hasNext()) {
			MonthlyCategoryTransactionEntity e = monthlycategorytransactionIterator.next();
			System.out.println("transaction category : "+e.getTransactioncategory());
			if(category.equalsIgnoreCase(e.getTransactioncategory())) {
				System.out.println("matched category: "+category);
				transactionAmountCat += e.getTransactionAmount();
				carbonEmissionCat += e.getTotalcarbonindex();
				transactionCnt++;
			}
		} 
		categoryObject = new JSONObject();
		categoryObject.put("carbonEmission", String.valueOf(carbonEmissionCat));
		categoryObject.put("trans_amt", String.valueOf(transactionAmountCat));
		categoryObject.put("categoryName", category);
		categoryObject.put("category_d", category);
		categoryObject.put("subheader", String.valueOf(transactionCnt)+" transactions");
		System.out.println("Transaction array size : "+ transactionsArray.size());
		System.out.println("Adding category : "+category + " carbon emission: " + String.valueOf(carbonEmissionCat));
		aggregatedSum += transactionAmountCat;
		aggregatedCarbon += carbonEmissionCat;
		transactionsArray.add(categoryObject);
		}
		
		JSONObject totals = new JSONObject();
		totals.put("aggregatedSum", String.valueOf(aggregatedSum));
		totals.put("aggregatedCarbon", String.valueOf(aggregatedCarbon));
		
		JSONObject dailyCategoryTransaction = new JSONObject();
		dailyCategoryTransaction.put("Totals", totals);
		dailyCategoryTransaction.put("Transactions", transactionsArray);
		return dailyCategoryTransaction;
   
    }
    
    @CrossOrigin
    @RequestMapping(value = "/monthlytransactiondata/{month}/{year}")
    public JSONArray monthlytransaction(@PathVariable("month") int month,@PathVariable("year") int year) {
    	List<MonthlyTransactionEntity> monthlyTransactionList=monthlytransactionService.getResponse(month,year);
    	ListIterator<MonthlyTransactionEntity> monthlycategorytransactionIterator = monthlyTransactionList.listIterator();
    	Map<String,Float> carbonEmissionMap = new HashMap<>();
    	while(monthlycategorytransactionIterator.hasNext()) {
    		MonthlyTransactionEntity transaction = monthlycategorytransactionIterator.next();
    		String date = transaction.getTransactiondate().toString();
    		if(carbonEmissionMap.containsKey(date)) {
    			float emissionindex = carbonEmissionMap.get(date);
    			carbonEmissionMap.put(date, emissionindex + transaction.getTotalcarbonindex());
    		}else {
    			carbonEmissionMap.put(date, transaction.getTotalcarbonindex());
    		}
    	}
    	JSONArray response = new JSONArray();
    	JSONObject EmissionperDay = null;
    	for(Map.Entry<String,Float> entry : carbonEmissionMap.entrySet()) {
    		EmissionperDay = new JSONObject();
    		EmissionperDay.put("transactionDate", entry.getKey());
    		EmissionperDay.put("carbonEmission", String.valueOf(entry.getValue()));
    		response.add(EmissionperDay);
    	}
    return response;
    }
}
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { LandingPageComponent } from './landing-page.component';
import { LandingPageRoutingModule } from './landing-page-routing.module';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [LandingPageComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    LandingPageRoutingModule
  ]
})
export class LandingPageModule { }

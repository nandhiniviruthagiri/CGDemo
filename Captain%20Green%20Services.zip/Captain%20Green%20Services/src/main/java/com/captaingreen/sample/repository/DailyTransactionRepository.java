package com.captaingreen.sample.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.captaingreen.sample.entity.DailyTransactionEntity;
 
@Repository
public interface DailyTransactionRepository extends CrudRepository<DailyTransactionEntity, Long> {
 
	@Query(
			  value = "SELECT * FROM transactiondata order by transactiondate desc",
			  nativeQuery = true)
    public List<DailyTransactionEntity> getAll();
}
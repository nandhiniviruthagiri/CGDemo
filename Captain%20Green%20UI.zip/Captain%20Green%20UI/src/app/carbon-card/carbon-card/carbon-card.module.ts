import { IonicModule } from '@ionic/angular';
import { MaterialModule } from './../../material.module';
import { CarbonCardComponent } from './../carbon-card.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [CarbonCardComponent],
  imports: [
    CommonModule,
    MaterialModule,
    IonicModule
  ],
  exports: [CarbonCardComponent]
})
export class CarbonCardModule { }

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { CarbonCalcPage } from './carbon-calc.page';

describe('CarbonCalcPage', () => {
  let component: CarbonCalcPage;
  let fixture: ComponentFixture<CarbonCalcPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarbonCalcPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(CarbonCalcPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

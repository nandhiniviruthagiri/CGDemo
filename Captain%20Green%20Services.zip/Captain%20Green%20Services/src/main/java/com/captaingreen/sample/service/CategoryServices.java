package com.captaingreen.sample.service;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import net.minidev.json.JSONArray;  
	public class CategoryServices{
		public ArrayList getCategories() {
			Connection con=null;
			ArrayList<String> categoryList = null;
	try{  	
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
			con=DriverManager.getConnection("jdbc:sqlserver://captaingreendb.database.windows.net:1433;database=CaptainGreenDB","captaingreendb","Rockstars!");  
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("SELECT distinct transactioncategory FROM transactiondata"); 
			categoryList = new ArrayList<String>();
			while(rs.next())  {
				String category = rs.getString("transactioncategory");
				categoryList.add(category);
			}
			con.close();  
		}catch(Exception e){ System.out.println(e);}
			return categoryList;
		}
		  
	} 
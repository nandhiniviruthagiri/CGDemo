package com.captaingreen.sample.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.captaingreen.sample.entity.SampleEntity;
import com.captaingreen.sample.entity.WeeklyCategoryTransactionEntity;
import com.captaingreen.sample.entity.DailyCategoryTransactionEntity;
import com.captaingreen.sample.entity.DailyTransactionEntity;
 
@Repository
public interface WeeklyCategoryTransactionRepository extends CrudRepository<WeeklyCategoryTransactionEntity, Long> {
 
	@Query(
			  value = "SELECT * FROM [dbo].[TransactionData]\r\n" + 
			  		"INNER JOIN (SELECT MAX(TransactionDate) CurrentDate FROM [dbo].[TransactionData])CurrentTransaction  \r\n" + 
			  		"ON YEAR(CurrentTransaction.CurrentDate) = YEAR(TransactionDate) AND MONTH(CurrentTransaction.CurrentDate) = MONTH(TransactionDate)  AND (DAY(TransactionDate) BETWEEN DAY(CurrentTransaction.CurrentDate)-7 AND DAY(CurrentTransaction.CurrentDate))\r\n",
			  nativeQuery = true)
    public List<WeeklyCategoryTransactionEntity> getAll();
	
}
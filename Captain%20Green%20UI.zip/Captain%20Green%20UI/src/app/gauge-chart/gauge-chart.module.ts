import { CourseDialogComponent } from './../course-dialog/course-dialog.component';
import { MaterialModule } from './../material.module';
import { GuageChartComponent } from './guage-chart/guage-chart.component';
import { HighchartsChartModule } from 'highcharts-angular';
import { IonicModule } from '@ionic/angular';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [GuageChartComponent],
  imports: [
    CommonModule,
    IonicModule,
    HighchartsChartModule,
    MaterialModule
  ],
  exports: [GuageChartComponent],
  entryComponents: [CourseDialogComponent]
})
export class GaugeChartModule { }

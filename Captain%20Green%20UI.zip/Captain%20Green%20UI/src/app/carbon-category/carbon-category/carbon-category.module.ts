import { CarbonCardModule } from './../../carbon-card/carbon-card/carbon-card.module';
import { MaterialModule } from './../../material.module';
import { IonicModule } from '@ionic/angular';
import { CarbonCategoryComponent } from './../carbon-category.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HighchartsChartModule } from 'highcharts-angular';



@NgModule({
  declarations: [CarbonCategoryComponent],
  imports: [
    CommonModule,
    IonicModule,
    MaterialModule,
    CarbonCardModule,
    HighchartsChartModule
  ], 
  exports: [CarbonCategoryComponent]
})
export class CarbonCategoryModule { }

import { CarbonCategoryModule } from './../carbon-category/carbon-category/carbon-category.module';
import { CarbonCalcPageModule } from './../carbon-calc/carbon-calc.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CarbonTrendsPageRoutingModule } from './carbon-trends-routing.module';

import { CarbonTrendsPage } from './carbon-trends.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CarbonCategoryModule,
    CarbonTrendsPageRoutingModule
  ],
  declarations: [CarbonTrendsPage]
})
export class CarbonTrendsPageModule {}

package com.captaingreen.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.captaingreen.sample.entity.SampleEntity;
import com.captaingreen.sample.entity.DailyCategoryTransactionEntity;
import com.captaingreen.sample.entity.DailyTransactionEntity;
import com.captaingreen.sample.entity.MonthlyCategoryTransactionEntity;
import com.captaingreen.sample.repository.SampleRepository;
import com.captaingreen.sample.repository.DailyCategoryTransactionRepository;
import com.captaingreen.sample.repository.DailyTransactionRepository;
import com.captaingreen.sample.repository.MonthlyCategoryTransactionRepository;
 
@Service
public class MonthlyCategoryTransactionService {
 
    @Autowired
    MonthlyCategoryTransactionRepository monthlycategorytransactionRepo;
 
        public List<MonthlyCategoryTransactionEntity> getAll() {
            return monthlycategorytransactionRepo.getAll();
        }
}
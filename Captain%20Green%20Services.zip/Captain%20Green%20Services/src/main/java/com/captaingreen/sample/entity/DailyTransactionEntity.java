package com.captaingreen.sample.entity;

//import java.util.Date;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transactiondata")
public class DailyTransactionEntity {
	
	@Id
	@Column(name = "transactionid")
	Integer transactionid;
	
	@Column(name = "transactiondate")
	Date transactiondate;
	
	@Column(name = "merchantname")
	String merchantname;
	
	@Column(name = "transactionamount")
	float transactionAmount;
	
	@Column(name = "totalcarbonindex")
	float totalcarbonindex;
	
	@Column(name = "transactioncategory")
	String transactioncategory;
	
	@Column(name = "carbonperdollar")
	float carbonperdollar;

	public String getMerchantname() {
		return merchantname;
	}

	public void setMerchantname(String merchantname) {
		this.merchantname = merchantname;
	}

	public String getTransactioncategory() {
		return transactioncategory;
	}

	public void setTransactioncategory(String transactioncategory) {
		this.transactioncategory = transactioncategory;
	}
	
	public Date getTransactiondate() {
		return transactiondate;
	}

	public void setTransactiondate(Date transactiondate) {
		this.transactiondate = transactiondate;
	}
	
	public float getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(float transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	
	public float getTotalcarbonindex() {
		return totalcarbonindex;
	}
	public void setTotalcarbonindex(float totalcarbonindex) {
		this.totalcarbonindex = totalcarbonindex;
	}
	public float getCarbonperdollar() {
		return carbonperdollar;
	}
	public void setCarbonperdollar(float carbonperdollar) {
		this.carbonperdollar = carbonperdollar;
	}
}
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { GiveBackPage } from './give-back.page';

describe('GiveBackPage', () => {
  let component: GiveBackPage;
  let fixture: ComponentFixture<GiveBackPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GiveBackPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(GiveBackPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

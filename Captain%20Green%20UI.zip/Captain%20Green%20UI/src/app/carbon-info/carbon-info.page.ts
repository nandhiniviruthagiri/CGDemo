import { Component, OnInit } from '@angular/core';
import { Router, } from '@angular/router';
import { NavController } from '@ionic/angular';
import * as Highcharts from "highcharts";
import HighchartsMore from 'highcharts/highcharts-more.src.js';
import MapModule from 'highcharts/modules/map';
//import {GiveBackComponent } from './give-back/give-back.component';

MapModule(Highcharts);
HighchartsMore(Highcharts);
const USA = require('@highcharts/map-collection/countries/us/us-all.geo.json');
const data = [
  ['us-ma', 9.468],
  ['us-wa', 10.88],
  ['us-ca', 9.256],
  ['us-or', 9.331],
  ['us-wi', 16.63],
  ['us-me', 12.467],
  ['us-mi', 15.37],
  ['us-nv', 12.55],
  ['us-nm', 23.402],
  ['us-co', 16.153],
  ['us-wy', 104.184],
  ['us-ks', 21.46],
  ['us-ne', 25.588],
  ['us-ok', 24.824],
  ['us-mo', 19.415],
  ['us-il', 16.029],
  ['us-in', 27.57],
  ['us-vt', 9.606],
  ['us-ar', 21.015],
  ['us-tx', 23.59],
  ['us-ri', 9.276],
  ['us-al', 23.79],
  ['us-ms', 23.187],
  ['us-nc', 11.944],
  ['us-va', 12.458],
  ['us-ia', 23.44],
  ['us-md', 9.623],
  ['us-de', 14.074],
  ['us-pa', 17.09],
  ['us-nj', 12.454],
  ['us-ny', 8.33],
  ['us-id', 10.991],
  ['us-sd', 17.447],
  ['us-ct', 9.464],
  ['us-nh', 10.338],
  ['us-ky', 28.082],
  ['us-oh', 17.857],
  ['us-tn', 15.57],
  ['us-wv', 51.935],
  ['us-dc', 4.11],
  ['us-la', 44.919],
  ['us-fl', 11.22],
  ['us-ga', 13.287],
  ['us-sc', 14.53],
  ['us-mn', 16.25],
  ['us-mt', 29.351],
  ['us-nd', 72.036],
  ['us-az', 12.624],
  ['us-ut', 19.369],
  ['us-hi', 12.95],
  ['us-ak', 21.015]
];

@Component({
  selector: 'app-carbon-calc',
  templateUrl: './carbon-info.page.html',
  styleUrls: ['./carbon-info.page.scss'],
})
export class CarbonInfoPage implements OnInit {

  chart: any;
  updateFromInput = false;
  Highcharts: typeof Highcharts = Highcharts;
  chartConstructor = "mapChart";
  chartCallback;
  chartOptions: {};

  constructor(private router: Router, private navCtrl: NavController) {

  }

  navigating(): void {
    //this.navCtrl.navigateForward('/carbon-info/give-back/');
    console.log("inside home()");
    this.router.navigate(['./tabs/carbon-info/give-back']);
  }
  navigateAlternate(): void {
    this.router.navigate(['./tabs/carbon-info/alternate']);
  }

  giveback() {
    console.log("giveback is clicked!");
    document.getElementById('giveimages').style.cssText = 'display:block';
    document.getElementById('inspireimages').style.cssText = 'display:none';
    document.getElementById('alternateimages').style.cssText = 'display:none';
    document.getElementById('compareimages').style.cssText = 'display:none';
  }

  inspire() {
    console.log("inspire is clicked!");
    document.getElementById('inspireimages').style.cssText = 'display:block';
    document.getElementById('giveimages').style.cssText = 'display:none';
    document.getElementById('alternateimages').style.cssText = 'display:none';
    document.getElementById('compareimages').style.cssText = 'display:none';
  }

  alternate() {
    console.log("alternate is clicked!");
    document.getElementById('alternateimages').style.cssText = 'display:block';
    document.getElementById('giveimages').style.cssText = 'display:none';
    document.getElementById('inspireimages').style.cssText = 'display:none';
    document.getElementById('compareimages').style.cssText = 'display:none';
  }

  compare() {
    console.log("compare is clicked!");
    document.getElementById('alternateimages').style.cssText = 'display:none';
    document.getElementById('giveimages').style.cssText = 'display:none';
    document.getElementById('inspireimages').style.cssText = 'display:none';
    document.getElementById('compareimages').style.cssText = 'display:block';
    Highcharts.charts.forEach(function (chart) {
      chart.reflow();
    });
  }

  ngOnInit() {
    console.log("info");
    this.initChart();
    document.getElementById('alternateimages').style.cssText = 'display:block';
    document.getElementById('giveimages').style.cssText = 'display:block';
    document.getElementById('inspireimages').style.cssText = 'display:block';
    document.getElementById('compareimages').style.cssText = 'display:block';
  }
  initChart() {

    this.chartOptions = {
      chart: {
        map: USA
      },
      title: {
        text: 'CO2 Emissions per Capita (in metric tons)',
        style: "{fontSize: 12}",
        margin: 0
      },
      colors: ["#bb2003", "#000000", "#03bb20"],
      // mapNavigation: {
      //   enabled: true,
      //   buttonOptions: {
      //     alignTo: 'spacingBox'
      //   }
      // },
      legend: {
        enabled: true,
        title: {
          text: "By Percentile"
        }
      },
      colorAxis: {
        min: 0,
        tickInterval: 20,
        dataClasses: [{
              from: 0,
              to: 10.4,
              color: '#21b2e9',
              name: '0-20'
          },{
              from:10.5,
              to:13.1,
              color: '#94f3fb',
              name: '20-40'
          },
          {
            from:13.1,
            to:17.4,
            color:'#ebf0be',
            name: '40-60'
        },
        {
              from:17.4,
              to:23.8,
              color:'#f3c671',
              name: '60-80'
          },{
              from:23.8,
              color:'#f46719',
              name: '80-100'
              
          }]
      },
      plotOptions: {
        series: {
          point: {
            events: {
              click: (c) => {
                console.log(this);
                console.log(c);
                if(c.point['hc-key'] != "us-ny"){
                  //says chart isn't found, but is doing what it should be doing?
                  this.chart.series[0].data[30].setState("");
                }
              }
            }
          }
        }
      },
      series: [{
        name: 'CO2 Emission',
        states: {
          hover: {
            color: '#cccccc'
          }
        },
        dataLabels: {
          enabled: false,
          format: '{point.properties.postal-code}'
        },
        allAreas: false,
        data: data,
        borderColor: 'white'
      } as Highcharts.SeriesMapOptions]
    };

    console.log(this.Highcharts)

  }

  callback(chart): void {
    console.log("calling back");
    console.log(chart);
    this.chart = chart;
    
    
    setTimeout(() => {
      chart.reflow();
      this.chart = chart;
      var point = chart.series[0].data[30];
      point.setState("hover");
      chart.series[0].chart.tooltip.refresh(point);
  }, 0);
  }



}

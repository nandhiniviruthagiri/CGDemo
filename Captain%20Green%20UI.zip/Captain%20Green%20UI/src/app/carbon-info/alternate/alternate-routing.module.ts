import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AlternatePage } from './alternate.page';

const routes: Routes = [
  {
    path: '',
    component: AlternatePage
  },
  {
    path: 'shopping',
    loadChildren: () => import('./shopping/shopping.module').then( m => m.ShoppingPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AlternatePageRoutingModule {}

import { IonicModule } from '@ionic/angular';
import { WelcomePageModule } from './../welcome-page/welcome-page/welcome-page.module';
import { CourseDialogComponent } from './course-dialog.component';
import { FormsModule } from '@angular/forms';
import { MaterialModule } from './../material.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [CourseDialogComponent],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    IonicModule
  ], 
  exports: [CourseDialogComponent]
})
export class CourseDialogModule { }

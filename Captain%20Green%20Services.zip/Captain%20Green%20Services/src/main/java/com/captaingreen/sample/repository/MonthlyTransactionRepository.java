package com.captaingreen.sample.repository;

import java.util.List;



import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.captaingreen.sample.entity.MonthlyTransactionEntity;



@Repository
public interface MonthlyTransactionRepository extends CrudRepository<MonthlyTransactionEntity, Long> {
	
	  @Query(value ="SELECT * FROM transactiondata WHERE MONTH(transactiondate) =:month and YEAR(transactiondate) =:year",
			  nativeQuery = true)
	  List<MonthlyTransactionEntity> getResponse(@Param("month") int month, @Param("year") int year);
	  
	
}
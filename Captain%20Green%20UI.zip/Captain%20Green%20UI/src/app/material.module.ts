import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  MatTableModule,
  MatStepperModule,
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatOptionModule,
  MatSelectModule,
  MatIconModule,
  MatPaginatorModule,
  MatSortModule, 
  MatCardModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatDividerModule,
  MatListModule,
  MatSliderModule,
  MatChipsModule,
  MatDialogModule
} from "@angular/material";


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
  ],
  exports: [MatTableModule,
    MatStepperModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSliderModule,
    MatDialogModule,
    MatInputModule,
    MatIconModule,
    MatOptionModule,
    MatSelectModule,
    MatPaginatorModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatChipsModule,
    MatCardModule,
    MatDividerModule,
    MatListModule,
    MatSortModule]
})
export class MaterialModule { }

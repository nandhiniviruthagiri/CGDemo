import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-carbon-card',
  templateUrl: './carbon-card.component.html',
  styleUrls: ['./carbon-card.component.scss'],
})
export class CarbonCardComponent implements OnInit {
  @Input() listItem;
  @Input() iconMapperWithColor;

  
  //{icon:'flight', color: '',
  iconsMapper = {
    'Travel': 'flight',
    "Food and Drinks": 'emoji_food_beverage',
    'Shopping': 'shopping_basket',
    'Gifts': 'card_giftcard',
    'Misc': 'dashboard',
    'Home': 'home'
  };

  constructor() { }

  ngOnInit() {
    console.log(this.listItem);
    console.log(this.iconMapperWithColor);
   }

   getIconColor(category) {
     return {
    'background-color': this.iconMapperWithColor[category.category_d].color,
     'border-radius': '24%',
     'color': 'white',

   };
  }

}

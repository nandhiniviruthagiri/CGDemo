import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carbon-trends',
  templateUrl: './carbon-trends.page.html',
  styleUrls: ['./carbon-trends.page.scss'],
})
export class CarbonTrendsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

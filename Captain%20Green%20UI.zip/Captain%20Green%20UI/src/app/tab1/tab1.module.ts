import { CourseDialogModule } from './../course-dialog/course-dialog.module';
import { CourseDialogComponent } from './../course-dialog/course-dialog.component';
import { GaugeChartModule } from './../gauge-chart/gauge-chart.module';
import { CarbonCardModule } from './../carbon-card/carbon-card/carbon-card.module';
import { MaterialModule } from './../material.module';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Tab1Page } from './tab1.page';

@NgModule({
  imports: [
    CarbonCardModule,
    IonicModule,
    MaterialModule,
    CommonModule,
    FormsModule,
    CourseDialogModule,
    GaugeChartModule,
    RouterModule.forChild([{ path: '', component: Tab1Page }])
  ],
  declarations: [Tab1Page]
 




})
export class Tab1PageModule {}

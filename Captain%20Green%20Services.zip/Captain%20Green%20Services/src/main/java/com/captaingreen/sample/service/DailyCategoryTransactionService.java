package com.captaingreen.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.captaingreen.sample.entity.DailyCategoryTransactionEntity;
import com.captaingreen.sample.repository.DailyCategoryTransactionRepository;
 
@Service
public class DailyCategoryTransactionService {
 
    @Autowired
    DailyCategoryTransactionRepository dailycategorytransactionRepo;
 
        public List<DailyCategoryTransactionEntity> getAll() {
        	System.out.println("service");
            return dailycategorytransactionRepo.getAll();
        }
}
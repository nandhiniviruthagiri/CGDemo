export interface Food {
    value: string;
    viewValue: string;
  }
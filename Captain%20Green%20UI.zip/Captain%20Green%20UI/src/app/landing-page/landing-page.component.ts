import { Component, OnInit } from '@angular/core';
import { SharedDataServiceService } from './../shared-services/shared-data-service.service';
import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Router } from '@angular/router';


@Component({
  selector: 'landing-page',
  templateUrl: 'landing-page.component.html',
  styleUrls: ['landing-page.component.scss']
})
export class LandingPageComponent implements OnInit {
  aggregatedSum;
  value = 10000;
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private router: Router, 
    private sharedDataServiceService: SharedDataServiceService
  ) {
    this.initializeApp();
  }
  public onLoginClick(){
    console.log('navigating');
    console.log(this.value);
    //this.sharedDataServiceService.setGoal = this.value;
    this.router.navigate(['./tabs']);
}
  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
 
 
 
  ngOnInit() {
   
  }
}

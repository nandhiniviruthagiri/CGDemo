import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'

@Component({
  selector: 'app-alternate',
  templateUrl: './alternate.page.html',
  styleUrls: ['./alternate.page.scss'],
})
export class AlternatePage implements OnInit {

  constructor(private router: Router) {}

  ngOnInit() {
  }


  navigateShopping(): void{
    this.router.navigate(['./tabs/carbon-info/alternate/shopping']);
  }
}

package com.captaingreen.sample.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.captaingreen.sample.entity.DailyCategoryTransactionEntity;
 
@Repository
public interface DailyCategoryTransactionRepository extends CrudRepository<DailyCategoryTransactionEntity, Long> {
 
	@Query(
			  value = "SELECT * FROM [dbo].[TransactionData] INNER JOIN (SELECT MAX(TransactionDate) CurrentDate FROM [dbo].[TransactionData])CurrentTransaction ON CurrentTransaction.CurrentDate = TransactionDate",
			  nativeQuery = true)
    public List<DailyCategoryTransactionEntity> getAll();
	
}
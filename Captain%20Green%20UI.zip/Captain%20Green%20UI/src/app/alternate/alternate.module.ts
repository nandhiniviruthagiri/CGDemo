import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AlternateRoutingModule } from './alternate-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AlternateRoutingModule
  ]
})
export class AlternateModule { }

package com.captaingreen.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.captaingreen.sample.entity.SampleEntity;
import com.captaingreen.sample.entity.WeeklyCategoryTransactionEntity;
import com.captaingreen.sample.entity.DailyCategoryTransactionEntity;
import com.captaingreen.sample.entity.DailyTransactionEntity;
import com.captaingreen.sample.repository.SampleRepository;
import com.captaingreen.sample.repository.WeeklyCategoryTransactionRepository;
import com.captaingreen.sample.repository.DailyCategoryTransactionRepository;
import com.captaingreen.sample.repository.DailyTransactionRepository;
 
@Service
public class WeeklyCategoryTransactionService {
 
    @Autowired
    WeeklyCategoryTransactionRepository weeklycategorytransactionRepo;
 
        public List<WeeklyCategoryTransactionEntity> getAll() {
            return weeklycategorytransactionRepo.getAll();
        }
}